const greeting = 'Hello World';
console.log(greeting);